package com.grupo9.digitalbooking.exception;

public class AuthenticationException extends Exception{
    public AuthenticationException(String message){
        super(message);
    }
}
