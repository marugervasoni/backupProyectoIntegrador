package com.grupo9.digitalbooking.exception;

public class DuplicatedValueException extends Exception {
    public DuplicatedValueException(String message) {
        super(message);
    }
}
